# MentorLMS Docker Setup Instructions

## Quick Start

### Prerequisites

- Docker & Docker Compose installed
- Git (for cloning repository)
- At least 4GB RAM available

### First-Time Setup

1. **Environment Configuration**

   ```bash
   # Copy environment files
   cp .env.example .env
   cp docker.env.example docker.env
   cp env/mysql.env.example env/mysql.env
   ```

2. **Start All Services**

   ```bash
   sudo docker compose up -d --build
   ```

3. **Database Setup**

   ```bash
   # Wait for MySQL to be healthy (check with: sudo docker compose ps)
   sudo docker compose exec php php artisan migrate:fresh --seed
   ```

4. **Access the Application**
   - **Main App**: http://localhost:8000
   - **phpMyAdmin**: http://localhost:8080 (root/secret)
   - **MailHog**: http://localhost:8025

## Services Configuration

### Web Server Options

#### Apache (Default)

```bash
# Apache is configured by default on port 8000
sudo docker compose up -d
```

#### Nginx (Alternative)

```bash
# Comment out Apache service and uncomment Nginx in docker-compose.yaml
sudo docker compose up -d
```

### Service Ports

- **Apache/Nginx**: 8000
- **MySQL**: 3307
- **Redis**: 6379
- **phpMyAdmin**: 8080
- **MailHog SMTP**: 1025
- **MailHog Web**: 8025

## Development Tools

### Using Development Profiles

#### Node.js Tools

```bash
# npm commands
sudo docker compose --profile tools run --rm npm install
sudo docker compose --profile tools run --rm npm run build

# Vite development server
sudo docker compose --profile dev up -d vite
# Access: http://localhost:5173
```

#### Composer Commands

```bash
sudo docker compose --profile tools run --rm composer install
sudo docker compose --profile tools run --rm composer update
```

#### Artisan Commands

```bash
sudo docker compose --profile tools run --rm artisan migrate
sudo docker compose --profile tools run --rm artisan tinker
```

## Environment Files

### .env Configuration

```bash
# Main Laravel environment
APP_NAME="MentorLMS"
APP_ENV=local
APP_DEBUG=true
APP_URL=http://localhost:8000

# Database settings
DB_CONNECTION=mysql
DB_HOST=mysql
DB_PORT=3306
DB_DATABASE=homestead
DB_USERNAME=homestead
DB_PASSWORD=secret
```

### docker.env Configuration

```bash
# Docker-specific settings
APP_NAME="Mentor LMS"
APP_ENV=production
APP_DEBUG=false
APP_URL=http://localhost:8000

# Redis and other services
REDIS_HOST=redis
CACHE_STORE=redis
SESSION_DRIVER=redis
QUEUE_CONNECTION=redis
```

### MySQL Environment (env/mysql.env)

```bash
MYSQL_DATABASE=homestead
MYSQL_USER=homestead
MYSQL_PASSWORD=secret
MYSQL_ROOT_PASSWORD=secret
```

## Common Issues & Solutions

### Port Already in Use

```bash
# Check what's using port 8000
sudo lsof -i :8000

# Stop conflicting services
sudo docker compose down
sudo docker stop $(sudo docker ps -q)
```

### Permission Issues

```bash
# Fix file permissions
sudo chown -R $USER:$USER .
sudo chmod -R 755 storage bootstrap/cache
```

### Database Connection Issues

```bash
# Check MySQL health
sudo docker compose ps mysql

# Reset database
sudo docker compose exec php php artisan migrate:fresh --seed
```

### Cache Issues

```bash
# Clear all caches
sudo docker compose exec php php artisan cache:clear
sudo docker compose exec php php artisan config:clear
sudo docker compose exec php php artisan route:clear
sudo docker compose exec php php artisan view:clear
```

## Volume Management

### Persistent Data

- **MySQL Data**: `mysql_data` volume
- **Node Modules**: `node_modules` volume
- **Logs**: `logs` volume

### Backup Database

```bash
# Export database
sudo docker compose exec mysql mysqldump -u root -psecret homestead > backup.sql

# Import database
sudo docker compose exec -T mysql mysql -u root -psecret homestead < backup.sql
```

## Switching Web Servers

### From Apache to Nginx

1. Edit `docker-compose.yaml`
2. Comment out Apache service
3. Uncomment Nginx service
4. Restart containers:
   ```bash
   sudo docker compose down
   sudo docker compose up -d
   ```

### From Nginx to Apache

1. Edit `docker-compose.yaml`
2. Comment out Nginx service
3. Uncomment Apache service
4. Restart containers

## Production Deployment

### Environment Settings

```bash
# Set production environment
APP_ENV=production
APP_DEBUG=false
```

### SSL Configuration

```bash
# Add SSL certificates to nginx/apache config
# Update APP_URL to https
```

### Performance Optimization

```bash
# Enable OPcache
# Configure Redis for caching
# Use production builds
```

## Troubleshooting

### Check Container Status

```bash
sudo docker compose ps
```

### View Logs

```bash
# All services
sudo docker compose logs

# Specific service
sudo docker compose logs php
sudo docker compose logs nginx
sudo docker compose logs mysql
```

### Enter Container

```bash
# PHP container
sudo docker compose exec php sh

# MySQL container
sudo docker compose exec mysql mysql -u root -psecret
```

### Reset Everything

```bash
# Stop and remove all containers
sudo docker compose down -v

# Remove all images
sudo docker rmi $(sudo docker images -q mentor-lms-*)

# Rebuild from scratch
sudo docker compose up -d --build
```

## Development Workflow

### Daily Development

```bash
# Start services
sudo docker compose up -d

# Make code changes

# Clear caches if needed
sudo docker compose exec php php artisan cache:clear

# View logs
sudo docker compose logs -f php
```

### Adding New Dependencies

```bash
# PHP packages
sudo docker compose --profile tools run --rm composer require package/name

# Node packages
sudo docker compose --profile tools run --rm npm install package-name
```

## Security Notes

- Change default passwords in production
- Use HTTPS in production
- Keep Docker images updated
- Regularly backup database
- Monitor container logs

## Support

For issues:

1. Check logs: `sudo docker compose logs`
2. Verify environment files
3. Check container status: `sudo docker compose ps`
4. Clear caches and restart

---

**Last Updated**: December 2025
**Version**: 1.0
